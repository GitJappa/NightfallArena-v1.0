from __future__ import annotations

import random
import sys

import pygame

from level import Level
from player import Player
from save import SaveManager
from settings import WIDTH, HEIGHT, FPS, GAME_TITLE, UPGRADE_POOL
from ui import UI


class Game:
    def __init__(self):
        pygame.init()
        pygame.mixer.init()
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption(GAME_TITLE)
        self.clock = pygame.time.Clock()
        self.running = True
        self.state = "start"
        self.level = Level()
        self.player = Player(WIDTH // 2, HEIGHT // 2)
        self.ui = UI(self.screen)
        self.save_manager = SaveManager()
        self.save_data = self.save_manager.load()
        self.current_upgrades = []
        self.flash = 0.0
        self.camera_shake = 0.0
        self.music_volume = self.save_data.settings.get("music_volume", 0.6) if self.save_data.settings else 0.6
        self.sound_volume = self.save_data.settings.get("sound_volume", 0.7) if self.save_data.settings else 0.7
        self.shop_offer = {"heal": 8, "weapon": 12}

    def reset_run(self):
        self.level = Level()
        self.player = Player(WIDTH // 2, HEIGHT // 2)
        self.state = "playing"
        self.current_upgrades = []
        self.flash = 0.0
        self.camera_shake = 0.0

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    if self.state == "playing":
                        self.state = "paused"
                    elif self.state == "paused":
                        self.state = "playing"
                elif event.key == pygame.K_q:
                    pass
                elif event.key == pygame.K_f:
                    self.toggle_fullscreen()
                elif event.key in {pygame.K_RETURN, pygame.K_SPACE}:
                    if self.state in {"game_over", "start"}:
                        self.reset_run()
                elif event.key == pygame.K_1 and self.state == "shop":
                    if self.player.coins >= self.shop_offer["heal"]:
                        self.player.coins -= self.shop_offer["heal"]
                        self.player.hp = min(self.player.max_hp, self.player.hp + 25)
                        self.state = "playing"
                elif event.key == pygame.K_2 and self.state == "shop":
                    if self.player.coins >= self.shop_offer["weapon"]:
                        self.player.coins -= self.shop_offer["weapon"]
                        self.player.current_weapon.damage *= 1.15
                        self.state = "playing"
                elif event.key == pygame.K_3 and self.state == "shop":
                    self.state = "playing"
                elif self.state == "upgrade":
                    if event.key == pygame.K_1:
                        self.apply_upgrade(self.current_upgrades[0].key)
                    elif event.key == pygame.K_2:
                        self.apply_upgrade(self.current_upgrades[1].key)
                    elif event.key == pygame.K_3:
                        self.apply_upgrade(self.current_upgrades[2].key)
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if self.state == "start":
                    self.reset_run()
                elif self.state == "upgrade":
                    pos = pygame.mouse.get_pos()
                    if 300 <= pos[0] <= 980:
                        for i, option in enumerate(self.current_upgrades):
                            y = 280 + i * 80
                            rect = pygame.Rect(300, y, 680, 60)
                            if rect.collidepoint(pos):
                                self.apply_upgrade(option.key)
                                break

    def toggle_fullscreen(self):
        flags = pygame.FULLSCREEN if not self.screen.get_flags() & pygame.FULLSCREEN else 0
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT), flags)

    def open_upgrade_menu(self):
        self.current_upgrades = random.sample(UPGRADE_POOL, 3)
        self.state = "upgrade"

    def apply_upgrade(self, choice: str):
        self.player.apply_upgrade(choice)
        self.state = "playing"
        self.flash = 0.20

    def run(self):
        while self.running:
            dt = self.clock.tick(FPS) / 1000.0
            self.handle_events()
            self.update(dt)
            self.draw()

        self.save_data.highscore = max(self.save_data.highscore, self.player.score)
        self.save_data.coins = self.player.coins
        self.save_manager.save(self.save_data)
        pygame.quit()
        sys.exit()

    def update(self, dt: float):
        if self.state == "playing":
            keys = pygame.key.get_pressed()
            self.player.update(dt, keys)
            self.level.update(dt, self.player)
            mouse_x, mouse_y = pygame.mouse.get_pos()
            self.player.mouse_x = (mouse_x - WIDTH / 2) / 120
            self.player.mouse_y = (mouse_y - HEIGHT / 2) / 120

            if self.player.level > self.level.level_id:
                self.level.level_id = self.player.level
                self.open_upgrade_menu()

            if self.level.elapsed_time > 35 and self.level.shop_timer > 35:
                self.state = "shop"
                self.level.shop_timer = 0.0

            if self.player.hp <= 0:
                self.state = "game_over"
                self.save_data.highscore = max(self.save_data.highscore, self.player.score)
                self.save_data.coins = self.player.coins
                self.save_manager.save(self.save_data)

            self.player.current_weapon.trigger(self.player, list(self.level.enemies), self.level.projectiles, self.level)
            self.level.projectiles.update(dt)

        if self.flash > 0:
            self.flash -= dt

    def draw(self):
        self.screen.fill((10, 10, 20))
        if self.state != "start":
            self.level.draw(self.screen, self.player)
            self.player.draw(self.screen, self.level.camera)
            self.ui.draw_hud(self.player, self.level, int(self.clock.get_fps()), self.level.camera)

        if self.state == "start":
            self.ui.draw_start_menu()
        elif self.state == "paused":
            self.ui.draw_pause()
        elif self.state == "upgrade":
            self.ui.draw_upgrade_menu(self.current_upgrades)
        elif self.state == "shop":
            self.ui.draw_shop(self.player)
        elif self.state == "game_over":
            self.ui.draw_game_over(self.player, self.level)

        if self.flash > 0:
            flash_surface = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
            flash_surface.fill((255, 255, 255, int(self.flash * 160)))
            self.screen.blit(flash_surface, (0, 0))

        pygame.display.flip()


if __name__ == "__main__":
    game = Game()
    game.run()
