from __future__ import annotations

import math
import random

import pygame


class Enemy(pygame.sprite.Sprite):
    def __init__(self, enemy_type: str, x: float, y: float):
        super().__init__()
        self.enemy_type = enemy_type
        self.x = x
        self.y = y
        self.radius = 16
        self.base_speed = 70
        self.speed = self.base_speed
        self.max_hp = 40
        self.hp = self.max_hp
        self.damage = 10
        self.color = (180, 180, 180)
        self.score_value = 10
        self.coin_value = 1
        self.boss = False
        self.hit_flash = 0.0
        self.image = pygame.Surface((self.radius * 2, self.radius * 2), pygame.SRCALPHA)
        self.rect = self.image.get_rect(center=(int(x), int(y)))
        self.anim_phase = random.randint(0, 3)
        self.setup_type(enemy_type)

    def setup_type(self, enemy_type: str):
        stats = {
            "Slime": {"speed": 74, "hp": 32, "damage": 7, "radius": 16, "color": (90, 220, 101), "score": 10, "coin": 1},
            "Skeleton": {"speed": 92, "hp": 52, "damage": 11, "radius": 18, "color": (210, 210, 210), "score": 16, "coin": 2},
            "Bat": {"speed": 110, "hp": 28, "damage": 8, "radius": 14, "color": (120, 120, 220), "score": 14, "coin": 2},
            "Ghost": {"speed": 108, "hp": 36, "damage": 12, "radius": 12, "color": (210, 210, 255), "score": 18, "coin": 2},
            "Demon": {"speed": 80, "hp": 95, "damage": 18, "radius": 20, "color": (220, 80, 80), "score": 30, "coin": 3},
            "BlackBlob": {"speed": 78, "hp": 44, "damage": 10, "radius": 17, "color": (25, 25, 30), "score": 20, "coin": 2},
            "Golem": {"speed": 64, "hp": 100, "damage": 16, "radius": 21, "color": (120, 120, 120), "score": 35, "coin": 4},
        }
        data = stats.get(enemy_type, stats["Slime"])
        self.speed = data["speed"]
        self.max_hp = data["hp"]
        self.hp = self.max_hp
        self.damage = data["damage"]
        self.radius = data["radius"]
        self.color = data["color"]
        self.score_value = data["score"]
        self.coin_value = data["coin"]
        self.image = pygame.Surface((self.radius * 2, self.radius * 2), pygame.SRCALPHA)
        self.rect = self.image.get_rect(center=(int(self.x), int(self.y)))

    def update(self, dt: float, player):
        if self.hit_flash > 0:
            self.hit_flash -= dt
        dx = player.x - self.x
        dy = player.y - self.y
        dist = max(1.0, math.hypot(dx, dy))
        self.x += (dx / dist) * self.speed * dt
        self.y += (dy / dist) * self.speed * dt
        self.rect.center = (int(self.x), int(self.y))

    def take_damage(self, amount: float, player):
        self.hp -= amount
        self.hit_flash = 0.08
        if self.hp <= 0:
            self.kill()
            player.score += self.score_value
            player.gain_coins(self.coin_value)
            player.gain_xp(self.score_value)

    def draw(self, screen, camera_offset):
        pos = (int(self.x - camera_offset[0]), int(self.y - camera_offset[1]))
        color = self.color if self.hit_flash <= 0 else (255, 255, 255)
        frame = (pygame.time.get_ticks() // 140) % 2
        bob = frame * 2

        if self.enemy_type == "BlackBlob":
            pygame.draw.rect(screen, color, (pos[0] - self.radius, pos[1] - self.radius + bob, self.radius * 2, self.radius * 2), 0)
            pygame.draw.rect(screen, (255, 255, 255), (pos[0] - 6, pos[1] - 2 + bob, 3, 3), 0)
            pygame.draw.rect(screen, (255, 255, 255), (pos[0] + 3, pos[1] - 2 + bob, 3, 3), 0)
        elif self.enemy_type == "Golem":
            pygame.draw.rect(screen, color, (pos[0] - self.radius, pos[1] - self.radius + bob, self.radius * 2, self.radius * 2), 0)
            pygame.draw.rect(screen, (40, 40, 40), (pos[0] - self.radius + 4, pos[1] - self.radius + 4 + bob, self.radius * 2 - 8, 4), 0)
            pygame.draw.rect(screen, (255, 255, 255), (pos[0] - 6, pos[1] - 2 + bob, 3, 3), 0)
            pygame.draw.rect(screen, (255, 255, 255), (pos[0] + 3, pos[1] - 2 + bob, 3, 3), 0)
        else:
            pygame.draw.rect(screen, color, (pos[0] - self.radius, pos[1] - self.radius + bob, self.radius * 2, self.radius * 2), 0)
            pygame.draw.rect(screen, (20, 20, 20), (pos[0] - 6, pos[1] - 2 + bob, 3, 3), 0)
            pygame.draw.rect(screen, (20, 20, 20), (pos[0] + 3, pos[1] - 2 + bob, 3, 3), 0)


class Boss(Enemy):
    def __init__(self, x: float, y: float):
        super().__init__("Demon", x, y)
        self.enemy_type = "Boss"
        self.max_hp = 260
        self.hp = self.max_hp
        self.speed = 70
        self.damage = 28
        self.radius = 28
        self.color = (150, 30, 40)
        self.score_value = 120
        self.coin_value = 8
        self.boss = True
        self.image = pygame.Surface((self.radius * 2, self.radius * 2), pygame.SRCALPHA)
        self.rect = self.image.get_rect(center=(int(x), int(y)))
