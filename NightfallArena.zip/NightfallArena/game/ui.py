from __future__ import annotations

import pygame

from settings import WIDTH, HEIGHT, GAME_TITLE


class UI:
    def __init__(self, screen):
        self.screen = screen
        self.font = pygame.font.SysFont("arial", 18)
        self.big_font = pygame.font.SysFont("arial", 40, bold=True)
        self.small_font = pygame.font.SysFont("arial", 14)

    def draw_bar(self, x: int, y: int, width: int, height: int, value: float, max_value: float, color: tuple[int, int, int], bg: tuple[int, int, int] = (40, 40, 40)):
        pygame.draw.rect(self.screen, bg, (x, y, width, height))
        fill = max(0, min(width, (value / max_value) * width))
        pygame.draw.rect(self.screen, color, (x, y, int(fill), height))

    def draw_hud(self, player, level, fps, camera_offset):
        self.draw_bar(20, 18, 220, 18, player.hp, player.max_hp, (220, 70, 70))
        self.draw_bar(20, 44, 220, 14, player.xp, player.level * 45, (110, 180, 255))
        level_text = self.font.render(f"Level {player.level}", True, (255, 255, 255))
        timer_text = self.font.render(f"Time {int(level.elapsed_time):03d}s", True, (255, 255, 255))
        fps_text = self.font.render(f"FPS {fps}", True, (255, 255, 255))
        coins_text = self.font.render(f"Coins {player.coins}", True, (255, 255, 255))
        score_text = self.font.render(f"Score {player.score}", True, (255, 255, 255))
        self.screen.blit(level_text, (250, 18))
        self.screen.blit(timer_text, (250, 44))
        self.screen.blit(fps_text, (250, 70))
        self.screen.blit(coins_text, (20, 72))
        self.screen.blit(score_text, (20, 96))

    def draw_menu(self, title: str, subtitle: str | None = None):
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 140))
        self.screen.blit(overlay, (0, 0))
        title_surf = self.big_font.render(title, True, (255, 255, 255))
        self.screen.blit(title_surf, (WIDTH // 2 - title_surf.get_width() // 2, HEIGHT // 2 - 120))
        if subtitle:
            text = self.small_font.render(subtitle, True, (220, 220, 220))
            self.screen.blit(text, (WIDTH // 2 - text.get_width() // 2, HEIGHT // 2 - 80))

    def draw_game_over(self, player, level):
        self.draw_menu("Game Over", f"Final score: {player.score}   Coins: {player.coins}")
        hint = self.small_font.render("Press Enter to restart", True, (255, 255, 255))
        self.screen.blit(hint, (WIDTH // 2 - hint.get_width() // 2, HEIGHT // 2 + 30))

    def draw_pause(self):
        self.draw_menu("Paused", "Press ESC to continue")

    def draw_start_menu(self):
        self.draw_menu(GAME_TITLE, "Press Enter or Space to start. WASD move, mouse aim, Q switch weapon, ESC pause")

    def draw_upgrade_menu(self, options):
        self.draw_menu("Level Up", "Choose a perk")
        for i, option in enumerate(options):
            y = 280 + i * 80
            box = pygame.Rect(300, y, 680, 60)
            pygame.draw.rect(self.screen, (60, 60, 60), box)
            pygame.draw.rect(self.screen, (120, 120, 120), box, 2)
            label = self.big_font.render(option.label, True, (255, 255, 255))
            desc = self.small_font.render(option.description, True, (220, 220, 220))
            self.screen.blit(label, (330, y + 10))
            self.screen.blit(desc, (330, y + 40))

    def draw_shop(self, player):
        self.draw_menu("Shop", f"Banked coins: {player.coins}")
        text = self.small_font.render("Press 1 buy heal, 2 buy weapon, 3 continue", True, (255, 255, 255))
        self.screen.blit(text, (WIDTH // 2 - text.get_width() // 2, HEIGHT // 2 + 60))
