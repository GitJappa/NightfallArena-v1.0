from __future__ import annotations

import math
from dataclasses import dataclass
from pathlib import Path

GAME_TITLE = "NightfallArena"
BASE_DIR = Path(__file__).resolve().parent
ASSET_DIR = BASE_DIR / "assets"
SPRITE_DIR = ASSET_DIR / "sprites"
SOUND_DIR = ASSET_DIR / "sounds"
MUSIC_DIR = ASSET_DIR / "music"
DATA_DIR = BASE_DIR / "data"
SAVE_PATH = DATA_DIR / "save.json"

WIDTH = 1280
HEIGHT = 720
FPS = 60
FULLSCREEN = False

PLAYER_SPEED = 260
PLAYER_RADIUS = 18
PLAYER_MAX_HP = 120
PLAYER_BASE_DAMAGE = 15
PLAYER_BASE_RANGE = 52
PLAYER_BASE_PROJECTILES = 1
PLAYER_BASE_ATTACK_SPEED = 0.6
PLAYER_XP_TO_LEVEL = 45
PLAYER_XP_BONUS = 1.2

ENEMY_SPAWN_RADIUS = 720
ENEMY_MAX_ACTIVE = 80
COIN_MIN_DISTANCE = 80

CAMERA_SHAKE_INTENSITY = 5
LEFT = "LEFT"
RIGHT = "RIGHT"
UP = "UP"
DOWN = "DOWN"


@dataclass
class UpgradeOption:
    key: str
    label: str
    description: str
    effect: str


UPGRADE_POOL = [
    UpgradeOption("damage", "Sharpened Steel", "+10% damage", "damage"),
    UpgradeOption("attack_speed", "Quick Hands", "+10% attack speed", "attack_speed"),
    UpgradeOption("projectiles", "Multi-Strike", "+1 projectile", "projectiles"),
    UpgradeOption("speed", "Sprint Boots", "+8% move speed", "speed"),
    UpgradeOption("max_hp", "Fortify", "+15 max HP", "max_hp"),
    UpgradeOption("hp_regen", "Healing Aura", "+1 HP/s regen", "hp_regen"),
    UpgradeOption("range", "Long Reach", "+12% attack range", "range"),
    UpgradeOption("crit", "Critical Focus", "+2% crit chance", "crit"),
]


def clamp(value: float, minn: float, maxx: float) -> float:
    return max(minn, min(maxx, value))


def distance(a, b) -> float:
    return math.hypot(a[0] - b[0], a[1] - b[1])
