from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from settings import SAVE_PATH


@dataclass
class SaveData:
    highscore: int = 0
    coins: int = 0
    unlocked_weapons: list[str] | None = None
    settings: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "highscore": self.highscore,
            "coins": self.coins,
            "unlocked_weapons": self.unlocked_weapons or ["Sword"],
            "settings": self.settings or {"music_volume": 0.6, "sound_volume": 0.7, "fullscreen": False},
        }


class SaveManager:
    def __init__(self, path: Path = SAVE_PATH):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def load(self) -> SaveData:
        if not self.path.exists():
            return SaveData()

        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
        except Exception:
            return SaveData()

        return SaveData(
            highscore=int(raw.get("highscore", 0)),
            coins=int(raw.get("coins", 0)),
            unlocked_weapons=raw.get("unlocked_weapons", ["Sword"]),
            settings=raw.get("settings", {"music_volume": 0.6, "sound_volume": 0.7, "fullscreen": False}),
        )

    def save(self, data: SaveData) -> None:
        self.path.write_text(json.dumps(data.to_dict(), indent=2), encoding="utf-8")
