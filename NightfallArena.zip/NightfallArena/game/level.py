from __future__ import annotations

import math
import random
import time

import pygame

from enemy import Enemy, Boss
from settings import ENEMY_MAX_ACTIVE, ENEMY_SPAWN_RADIUS, WIDTH, HEIGHT, clamp


class Level:
    def __init__(self, world_size: int = 4000):
        self.world_size = world_size
        self.enemies = pygame.sprite.Group()
        self.projectiles = pygame.sprite.Group()
        self.effects = []
        self.camera = [0, 0]
        self.spawn_timer = 0.0
        self.elapsed_time = 0.0
        self.shop_timer = 0.0
        self.dt = 0.0
        self.enemy_types = ["Slime", "Skeleton", "Bat", "Ghost", "Demon", "BlackBlob", "Golem"]
        self.enemy_counter = 0
        self.level_id = 1

    def update(self, dt: float, player):
        self.dt = dt
        self.elapsed_time += dt
        self.shop_timer += dt
        self.spawn_timer += dt
        self.camera[0] = player.x - WIDTH / 2
        self.camera[1] = player.y - HEIGHT / 2
        self.spawn_enemies(player)
        self.projectiles.update(dt)

        for projectile in list(self.projectiles):
            if not projectile.alive:
                self.projectiles.remove(projectile)

        for enemy in list(self.enemies):
            enemy.update(dt, player)
            if self.collides(player, enemy):
                player.take_damage(enemy.damage * dt * 5)

        for projectile in list(self.projectiles):
            for enemy in list(self.enemies):
                if math.hypot(projectile.x - enemy.x, projectile.y - enemy.y) < projectile.radius + enemy.radius:
                    enemy.take_damage(projectile.damage, player)
                    projectile.alive = False
                    projectile.kill()
                    break

        for effect in list(self.effects):
            if hasattr(effect, "update"):
                effect.update(dt)
                if hasattr(effect, "active") and effect.active <= 0:
                    self.effects.remove(effect)
            elif isinstance(effect, dict):
                effect["life"] -= dt
                if effect.get("life", 0) <= 0:
                    self.effects.remove(effect)
            else:
                self.effects.remove(effect)

        self.check_wave(player)

    def spawn_enemies(self, player):
        if self.spawn_timer < 0.6:
            return
        self.spawn_timer = 0.0
        if len(self.enemies) >= ENEMY_MAX_ACTIVE:
            return
        angle = random.random() * math.tau
        distance = random.randint(ENEMY_SPAWN_RADIUS // 2, ENEMY_SPAWN_RADIUS)
        x = player.x + math.cos(angle) * distance
        y = player.y + math.sin(angle) * distance
        enemy_type = random.choice(self.enemy_types)
        enemy = Enemy(enemy_type, x, y)
        self.enemies.add(enemy)
        self.enemy_counter += 1

        if self.enemy_counter % 20 == 0:
            boss = Boss(player.x + 200, player.y + 200)
            self.enemies.add(boss)

    def check_wave(self, player):
        if self.elapsed_time > 20 and self.level_id == 1:
            self.level_id = 2
            self.enemy_types = ["Slime", "Skeleton", "Bat", "Ghost", "Demon", "BlackBlob", "Golem"]

    def draw(self, screen, player):
        for tile_y in range(-1, 2):
            for tile_x in range(-1, 2):
                pygame.draw.rect(screen, (22, 18, 22), (tile_x * 220 - self.camera[0] % 220, tile_y * 220 - self.camera[1] % 220, 220, 220), 2)

        for projectile in self.projectiles:
            projectile.draw(screen, self.camera)

        for enemy in self.enemies:
            enemy.draw(screen, self.camera)

        for effect in self.effects:
            if hasattr(effect, "draw"):
                effect.draw(screen, self.camera)
            elif isinstance(effect, dict) and effect.get("type") == "zap":
                pygame.draw.line(screen, (150, 235, 255), (int(effect["x"] - self.camera[0]), int(effect["y"] - self.camera[1])), (int(effect["x"] - self.camera[0] + random.randint(-20, 20)), int(effect["y"] - self.camera[1] + random.randint(-20, 20))), 3)

    def collides(self, player, enemy):
        return math.hypot(player.x - enemy.x, player.y - enemy.y) < player.radius + enemy.radius

    def add_effect(self, effect):
        self.effects.append(effect)
