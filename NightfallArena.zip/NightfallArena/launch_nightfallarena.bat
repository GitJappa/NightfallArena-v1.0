@echo off
cd /d "%~dp0game"
"C:\Users\Jasper Kingma\AppData\Local\Programs\Python\Python313\python.exe" main.py
