from __future__ import annotations

import math
import random

import pygame

from projectile import Projectile, MeleeArc


class Weapon:
    def __init__(self, name: str, damage: float, cooldown: float, projectile_speed: float = 0, range_value: float = 70):
        self.name = name
        self.damage = damage
        self.cooldown = cooldown
        self.projectile_speed = projectile_speed
        self.range_value = range_value
        self.projectiles = 1
        self.attack_speed = 1.0
        self.level = 1
        self.cooldown_timer = 0.0
        self.crit_chance = 0.02

    def trigger(self, player, enemies, projectiles_group, level):
        return None

    def apply_upgrade(self, key: str):
        if key == "damage":
            self.damage *= 1.12
        elif key == "attack_speed":
            self.attack_speed *= 1.10
            self.cooldown *= 0.92
        elif key == "projectiles":
            self.projectiles += 1
        elif key == "range":
            self.range_value *= 1.10
        elif key == "crit":
            self.crit_chance = min(0.4, self.crit_chance + 0.02)

    def can_fire(self, dt: float) -> bool:
        self.cooldown_timer -= dt
        if self.cooldown_timer <= 0:
            self.cooldown_timer = 0
            return True
        return False

    def set_fire_delay(self):
        self.cooldown_timer = self.cooldown / self.attack_speed


class Firearm(Weapon):
    def __init__(self):
        super().__init__("Firearm", 16, 0.34, projectile_speed=500, range_value=240)

    def trigger(self, player, enemies, projectiles_group, level):
        if not self.can_fire(level.dt):
            return None
        self.set_fire_delay()
        dx = player.mouse_x
        dy = player.mouse_y
        length = math.hypot(dx, dy)
        if length == 0:
            dx, dy = 1, 0
            length = 1
        angle = math.atan2(dy, dx)
        for i in range(self.projectiles):
            spread = (i - (self.projectiles - 1) / 2) * 0.06
            a = angle + spread
            proj = Projectile(player.x, player.y, math.cos(a) * self.projectile_speed, math.sin(a) * self.projectile_speed, self.damage, radius=5, color=(255, 215, 90), life=0.9)
            projectiles_group.add(proj)
        return True


class Sword(Weapon):
    def __init__(self):
        super().__init__("Sword", 22, 0.55, range_value=72)

    def trigger(self, player, enemies, projectiles_group, level):
        if not self.can_fire(level.dt):
            return None
        self.set_fire_delay()
        angle = math.atan2(player.mouse_y, player.mouse_x)
        slash = MeleeArc(player.x, player.y, self.range_value, angle)
        level.effects.append(slash)
        for enemy in enemies:
            vx = enemy.x - player.x
            vy = enemy.y - player.y
            dist = math.hypot(vx, vy)
            if dist <= self.range_value:
                if math.cos(angle) * vx + math.sin(angle) * vy >= 0:
                    enemy.take_damage(self.damage, player)
        return True


class Fireball(Weapon):
    def __init__(self):
        super().__init__("Fireball", 18, 0.75, projectile_speed=420, range_value=160)

    def trigger(self, player, enemies, projectiles_group, level):
        if not self.can_fire(level.dt):
            return None
        self.set_fire_delay()
        dx = player.mouse_x
        dy = player.mouse_y
        base = math.hypot(dx, dy)
        if base == 0:
            dx, dy = 1, 0
        for i in range(self.projectiles):
            offset = (i - (self.projectiles - 1) / 2) * 0.12
            angle = math.atan2(dy, dx) + offset
            proj = Projectile(player.x, player.y, math.cos(angle) * self.projectile_speed, math.sin(angle) * self.projectile_speed, self.damage, radius=7, color=(255, 110, 20), life=1.8)
            projectiles_group.add(proj)
        return True


class MagicWand(Weapon):
    def __init__(self):
        super().__init__("Magic Wand", 14, 0.50, projectile_speed=430, range_value=220)

    def trigger(self, player, enemies, projectiles_group, level):
        if not self.can_fire(level.dt):
            return None
        self.set_fire_delay()
        dx = player.mouse_x
        dy = player.mouse_y
        angle = math.atan2(dy, dx)
        spread = 0.22 * max(1, self.projectiles - 1)
        for i in range(self.projectiles):
            a = angle + random.uniform(-spread, spread)
            proj = Projectile(player.x, player.y, math.cos(a) * self.projectile_speed, math.sin(a) * self.projectile_speed, self.damage, radius=6, color=(100, 215, 255), life=1.6)
            projectiles_group.add(proj)
        return True


class Lightning(Weapon):
    def __init__(self):
        super().__init__("Lightning", 16, 0.65, range_value=280)

    def trigger(self, player, enemies, projectiles_group, level):
        if not self.can_fire(level.dt):
            return None
        self.set_fire_delay()
        if not enemies:
            return True
        target = min(enemies, key=lambda e: math.hypot(e.x - player.x, e.y - player.y))
        target.take_damage(self.damage, player)
        level.effects.append({"type": "zap", "x": target.x, "y": target.y, "life": 0.18})
        return True


class Axe(Weapon):
    def __init__(self):
        super().__init__("Axe", 24, 0.82, projectile_speed=360, range_value=150)

    def trigger(self, player, enemies, projectiles_group, level):
        if not self.can_fire(level.dt):
            return None
        self.set_fire_delay()
        dx = player.mouse_x
        dy = player.mouse_y
        angle = math.atan2(dy, dx)
        for i in range(self.projectiles):
            proj = Projectile(player.x, player.y, math.cos(angle) * self.projectile_speed, math.sin(angle) * self.projectile_speed, self.damage, radius=9, color=(200, 120, 50), life=1.5)
            projectiles_group.add(proj)
        return True
