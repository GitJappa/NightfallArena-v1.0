from __future__ import annotations

import math
import pygame

from settings import clamp


class Projectile(pygame.sprite.Sprite):
    def __init__(self, x: float, y: float, velocity_x: float, velocity_y: float, damage: float, radius: int = 8, color=(255, 128, 0), life: float = 1.2):
        super().__init__()
        self.x = x
        self.y = y
        self.vx = velocity_x
        self.vy = velocity_y
        self.damage = damage
        self.radius = radius
        self.color = color
        self.life = life
        self.alive = True
        self.image = pygame.Surface((radius * 2, radius * 2), pygame.SRCALPHA)
        self.rect = self.image.get_rect(center=(int(self.x), int(self.y)))

    def update(self, dt: float):
        self.life -= dt
        if self.life <= 0:
            self.alive = False
            self.kill()
            return

        self.x += self.vx * dt
        self.y += self.vy * dt
        self.rect.center = (int(self.x), int(self.y))

    def draw(self, screen, camera_offset):
        if not self.alive:
            return
        pos = (int(self.x - camera_offset[0]), int(self.y - camera_offset[1]))
        pygame.draw.circle(screen, self.color, pos, self.radius)
        pygame.draw.circle(screen, (255, 255, 255), pos, self.radius, 1)


class MeleeArc:
    def __init__(self, x: float, y: float, radius: float, angle: float, active: float = 0.12, color=(255, 230, 150)):
        self.x = x
        self.y = y
        self.radius = radius
        self.angle = angle
        self.active = active
        self.color = color

    def update(self, dt: float):
        self.active -= dt

    def draw(self, screen, camera_offset):
        if self.active <= 0:
            return
        pos = (int(self.x - camera_offset[0]), int(self.y - camera_offset[1]))
        pygame.draw.arc(screen, self.color, (pos[0] - self.radius, pos[1] - self.radius, self.radius * 2, self.radius * 2), self.angle - 0.6, self.angle + 0.6, 4)
