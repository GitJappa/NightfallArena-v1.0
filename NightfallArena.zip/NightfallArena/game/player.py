from __future__ import annotations

import math

import pygame

from settings import PLAYER_RADIUS, PLAYER_MAX_HP, PLAYER_SPEED, clamp
from weapon import Firearm


class Player(pygame.sprite.Sprite):
    def __init__(self, x: float, y: float):
        super().__init__()
        self.x = x
        self.y = y
        self.radius = PLAYER_RADIUS
        self.speed = PLAYER_SPEED
        self.base_speed = PLAYER_SPEED
        self.hp = PLAYER_MAX_HP
        self.max_hp = PLAYER_MAX_HP
        self.hp_regen = 0.5
        self.damage = 15
        self.attack_speed = 1.0
        self.range = 72
        self.projectiles = 1
        self.crit_chance = 0.02
        self.xp = 0
        self.level = 1
        self.coins = 0
        self.score = 0
        self.mouse_x = 1
        self.mouse_y = 0

        self.weapon_names = ["Firearm"]
        self.weapon_map = {
            "Firearm": Firearm(),
        }
        self.current_weapon = self.weapon_map["Firearm"]
        self.weapon_index = 0
        self.facing = 0
        self.flash_timer = 0.0
        self.invulnerable = 0.0

    def update(self, dt: float, keys):
        if self.invulnerable > 0:
            self.invulnerable -= dt
        self.hp = clamp(self.hp + self.hp_regen * dt, 0, self.max_hp)
        movement = pygame.math.Vector2()
        if keys[pygame.K_w]: movement.y -= 1
        if keys[pygame.K_s]: movement.y += 1
        if keys[pygame.K_a]: movement.x -= 1
        if keys[pygame.K_d]: movement.x += 1
        if movement.length() > 0:
            movement.normalize_ip()
            self.x += movement.x * self.speed * dt
            self.y += movement.y * self.speed * dt

    def take_damage(self, amount: float):
        if self.invulnerable > 0:
            return
        self.hp -= amount
        self.invulnerable = 0.25
        self.flash_timer = 0.08

    def gain_xp(self, amount: float):
        self.xp += amount
        while self.xp >= self.level * 45:
            self.xp -= self.level * 45
            self.level += 1
            self.flash_timer = 0.35

    def gain_coins(self, amount: int):
        self.coins += amount

    def cycle_weapon(self):
        self.current_weapon = self.weapon_map[self.weapon_names[self.weapon_index]]

    def apply_upgrade(self, key: str):
        if key == "speed":
            self.speed *= 1.08
        elif key == "max_hp":
            self.max_hp += 15
            self.hp += 15
        elif key == "hp_regen":
            self.hp_regen += 1.0
        elif key == "damage":
            self.damage *= 1.12
        elif key == "projectiles":
            self.projectiles += 1
        elif key == "attack_speed":
            self.attack_speed *= 1.1
        elif key == "range":
            self.range *= 1.10
        elif key == "crit":
            self.crit_chance = min(0.5, self.crit_chance + 0.02)
        self.current_weapon.apply_upgrade(key)

    def draw(self, screen, camera_offset):
        pos = (int(self.x - camera_offset[0]), int(self.y - camera_offset[1]))
        frame = (pygame.time.get_ticks() // 120) % 2
        lift = frame * 2

        # head
        pygame.draw.rect(screen, (54, 60, 82), (pos[0] - 10, pos[1] - 24, 20, 16), 0)
        # face
        pygame.draw.rect(screen, (180, 220, 255), (pos[0] - 8, pos[1] - 22, 16, 12), 0)
        # eye pupils
        pygame.draw.rect(screen, (20, 20, 20), (pos[0] - 5, pos[1] - 18, 3, 3), 0)
        pygame.draw.rect(screen, (20, 20, 20), (pos[0] + 2, pos[1] - 18, 3, 3), 0)
        # torso
        pygame.draw.rect(screen, (40, 155, 210), (pos[0] - 12, pos[1] - 8, 24, 24), 0)
        # armor straps
        pygame.draw.rect(screen, (15, 25, 40), (pos[0] - 12, pos[1] - 8, 24, 4), 0)
        # arms
        pygame.draw.rect(screen, (68, 90, 120), (pos[0] - 16, pos[1] - 2 + lift, 4, 18), 0)
        pygame.draw.rect(screen, (68, 90, 120), (pos[0] + 12, pos[1] - 2 - lift, 4, 18), 0)
        # legs
        pygame.draw.rect(screen, (22, 30, 48), (pos[0] - 9, pos[1] + 16, 8, 14), 0)
        pygame.draw.rect(screen, (22, 30, 48), (pos[0] + 1, pos[1] + 16, 8, 14), 0)
        # firearm
        pygame.draw.rect(screen, (120, 120, 120), (pos[0] + 14, pos[1] - 2, 18, 6), 0)
        pygame.draw.rect(screen, (220, 220, 220), (pos[0] + 28, pos[1] - 1, 5, 4), 0)
        # lens of aim
        pygame.draw.rect(screen, (255, 250, 140), (int(pos[0] + self.mouse_x * 12), int(pos[1] + self.mouse_y * 12), 4, 4), 0)

    def weapon_vector(self):
        return self.mouse_x, self.mouse_y
